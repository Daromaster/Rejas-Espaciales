// Revisión: 1003-B - 2025-05-08 02:20 GMT-3
class MotorReja {}
let rejaActiva = new MotorReja();
// Revisión: 1003-B - 2025-05-08 02:20 GMT-3