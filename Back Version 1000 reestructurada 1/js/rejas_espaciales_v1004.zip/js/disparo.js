// Revisión: 1002 - 2025-05-08 02:05 GMT-3
function evaluarDisparo() { return true; }
// Revisión: 1002 - 2025-05-08 02:05 GMT-3