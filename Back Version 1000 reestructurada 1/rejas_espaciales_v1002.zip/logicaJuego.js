// Revisión: 1002 - 2025-05-08 02:05 GMT-3
let estadoActual = "cubierta";
let tiempoEstado = 0;
const duracionCubierta = 2000;
const duracionDescubierta = 4000;
function actualizarLogicaJuego() {
  tiempoEstado += 16;
  if (estadoActual === "cubierta" && tiempoEstado >= duracionCubierta) {
    cambiarEstado("descubierta");
  } else if (estadoActual === "descubierta" && tiempoEstado >= duracionDescubierta) {
    cambiarEstado("cubierta");
  }
}
function cambiarEstado(nuevoEstado) { estadoActual = nuevoEstado; tiempoEstado = 0; }
function getEstadoActual() { return estadoActual; }
// Revisión: 1002 - 2025-05-08 02:05 GMT-3