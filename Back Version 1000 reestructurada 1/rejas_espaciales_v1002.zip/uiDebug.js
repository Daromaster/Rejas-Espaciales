// Revisión: 1002 - 2025-05-08 02:05 GMT-3
function dibujarPunto(ctx, x, y, color = "red", radio = 5) {
  ctx.beginPath(); ctx.fillStyle = color;
  ctx.arc(x, y, radio, 0, 2 * Math.PI);
  ctx.fill();
}
function dibujarCuadro(ctx, x, y, color = "lime", tam = 60) {
  ctx.fillStyle = color;
  ctx.fillRect(x - tam / 2, y - tam / 2, tam, tam);
}
function dibujarIndicadoresDebug(ctx) {}
// Revisión: 1002 - 2025-05-08 02:05 GMT-3