// Revisión: 1003-B - 2025-05-08 02:20 GMT-3

class MotorReja {
  constructor(nombre = "base") {
    this.nombre = nombre;
    this.interseccionesBase = [];
    this.offsetX = 0;
    this.offsetY = 0;
  }
  generarInterseccionesBase() { this.interseccionesBase = []; }
  getInterseccionesActuales() {
    return this.interseccionesBase.map(p => ({ x: p.x + this.offsetX, y: p.y + this.offsetY }));
  }
  actualizar() {}
  dibujar(ctx) {}
  getOffset() { return { x: this.offsetX, y: this.offsetY }; }
  getZonasCubiertas() { return []; }
  getCeldasDescubiertas(radioPelota) {
    return this.getInterseccionesActuales().filter(p => true);
  }
}

let rejaActiva = new MotorReja();

// Revisión: 1003-B - 2025-05-08 02:20 GMT-3