// Revisión: 1002 - 2025-05-08 02:05 GMT-3
window.addEventListener("DOMContentLoaded", () => {
  const canvasPrincipal = document.getElementById("canvas-juego");
  const ctxPrincipal = canvasPrincipal.getContext("2d");
  const ancho = canvasPrincipal.width;
  const alto = canvasPrincipal.height;

  crearCapas(["fondo", "reja", "pelota", "ui"], ancho, alto);

  function render() {
    actualizarLogicaJuego();
    pelotas.forEach(p => p.actualizar());

    getCtx("fondo").clearRect(0, 0, ancho, alto);
    getCtx("reja").clearRect(0, 0, ancho, alto);
    getCtx("pelota").clearRect(0, 0, ancho, alto);
    getCtx("ui").clearRect(0, 0, ancho, alto);

    pelotas.forEach(p => p.dibujar(getCtx("pelota")));
    copiarCapasEn(ctxPrincipal);
    requestAnimationFrame(render);
  }
  render();
});
// Revisión: 1002 - 2025-05-08 02:05 GMT-3