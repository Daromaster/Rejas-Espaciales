// Revisión: 1002 - 2025-05-08 02:05 GMT-3
// TODO: agregar parámetros globales del juego
// Revisión: 1002 - 2025-05-08 02:05 GMT-3