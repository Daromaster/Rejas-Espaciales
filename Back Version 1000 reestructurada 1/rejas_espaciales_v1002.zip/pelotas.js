// Revisión: 1002 - 2025-05-08 02:05 GMT-3
class Pelota {
  constructor(x, y, tipo = "normal") {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
    this.radio = 12;
    this.destino = { x: x, y: y };
  }
  actualizar() {}
  dibujar(ctx) {}
}
const pelotas = [];
// Revisión: 1002 - 2025-05-08 02:05 GMT-3